<?php
include "db.php";
$data=array();
$q=mysqli_query($con,"select * from `assistsocial`");
while ($row=mysqli_fetch_object($q)){
 $data[]=array_map('utf8_encode', $row); ;
 
}
echo json_encode($data); 

?>