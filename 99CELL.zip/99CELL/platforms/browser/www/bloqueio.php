<?php

 include "db.php";
 $cpf=$_GET['cpf'];

$data=array();
$q=mysqli_query($con,"
select * from `cliente` where  `cpf`='$cpf'"  );
while ($row=mysqli_fetch_object($q)){
 $data[]=$row ;
 
}
echo json_encode($data); 
 

 ?>