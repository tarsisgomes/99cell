<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("srv84.prodns.com.br","cellcom_user","cell18l18","cellcom_bd") or die ("could not connect database");
?>