<?php
include "db.php";
 if(isset($_GET['id']) && isset($_GET['idm']))
 {
 $id= $_GET['id'];
 $idm= $_GET['idm'];
$data=array();
$q=mysqli_query($con,"
select * from `assistsocial` where  `programa`='$id' and  `categoria`='$idm' order by  titulo"    );
while ($row=mysqli_fetch_array($q)){
  $data[]=array_map('utf8_encode', $row); 
 
}

echo json_encode($data); 


 }
?>