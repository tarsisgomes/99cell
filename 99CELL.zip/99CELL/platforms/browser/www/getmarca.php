<?php
header("Content-Type: text/html; charset=UTF-8",true);
include "db.php";
$data=array();
$con->set_charset("utf8");
$q=mysqli_query($con,"
select * from `categoria` where  `id`='$id'"   );
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
 
}
echo json_encode($data); 

?>