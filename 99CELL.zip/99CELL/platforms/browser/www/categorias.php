<?php
header("Content-Type: text/html; charset=UTF-8",true);
include "db.php";
$data=array();
$marca2= $_GET['marca'];
$q=mysqli_query($con,"
select assistsocial.categoria,assistsocial.programa,assist_programas.id,assist_programas.nome FROM assistsocial, assist_programas  WHERE assistsocial.categoria  = '$marca2' and assistsocial.programa = assist_programas.id  group by assist_programas.nome order by assist_programas.nome "  );

while ($row=mysqli_fetch_array($q)){
 $data[]=array_map('utf8_encode', $row); ;
}


echo json_encode($data); 

?>