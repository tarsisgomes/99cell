<?php
	header("Access-Control-Allow-Origin: *");		
	$keyword = strval($_POST['query']);
	$search_param = "%{$keyword}%";
	$conn =new mysqli('srv84.prodns.com.br', 'cellcom_user', 'cell18l18' , 'cellcom_bd');

	$sql = $conn->prepare("SELECT * FROM assistsocial WHERE titulo LIKE ?");
	$sql->bind_param("s",$search_param);			
	$sql->execute();
	$result = $sql->get_result();
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
		$countryResult[] = $row["titulo"];
		}
		echo json_encode($countryResult);
	}
	$conn->close();
?>

