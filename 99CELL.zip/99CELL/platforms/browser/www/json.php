<?php
header("Content-Type: text/html; charset=UTF-8",true);
include "db.php";
$data=array();
$q=mysqli_query($con,"
select * from `assistsocial` order by  titulo"  );
while ($row=mysqli_fetch_array($q)){
  $data[]=array_map('utf8_encode', $row); ;
 
}
echo json_encode($data); 

?>