<?php
header("Content-Type: text/html; charset=UTF-8",true);
header("Access-Control-Allow-Origin: *");
 include "db.php";

 $nome=utf8_decode($_POST['nome']);
 $nascimento=utf8_decode($_POST['nascimento']);
 $email=utf8_decode($_POST['email']);
 $fone=utf8_decode($_POST['fone']);	 
 $responsavel=utf8_decode($_POST['responsavel']);
 $endereco=utf8_decode($_POST['endereco']);	 

 $cpf=$_POST['cpf'];
 $bairro=utf8_decode($_POST['bairro']);
 $numero=$_POST['numero'];
 $cidade=utf8_decode($_POST['cidade']);
 $estado=$_POST['estado'];
 $cep=$_POST['cep'];
$texto= "Cadastro efetuado em: " . date("d/m/Y");

$escola=utf8_decode($_POST['escola']);
$onde=utf8_decode($_POST['onde']);

 $q=mysqli_query($con,"INSERT INTO `cliente` (nome,nascimento,email,telefone,responsavel,endereco,cpf,bairro,numero,cidade,estado,cep,texto,escola,onde) VALUES ('$nome','$nascimento','$email','$fone','$responsavel','$endereco','$cpf','$bairro','$numero','$cidade','$estado','$cep','$texto','$escola','$onde')");
 if($q)
  echo "success";
 else
  echo "error";

 ?>