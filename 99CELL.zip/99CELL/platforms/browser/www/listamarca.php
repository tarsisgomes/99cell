<?php
include "db.php";
 if(isset($_GET['id']))
 {
 $id= $_GET['id'];
$data=array();
$q=mysqli_query($con,"
select * from `assistsocial` where  `categoria`='$id'"  );
while ($row=mysqli_fetch_object($q)){
 $data[]=$row ;
 
}
echo json_encode($data); 


 }
?>